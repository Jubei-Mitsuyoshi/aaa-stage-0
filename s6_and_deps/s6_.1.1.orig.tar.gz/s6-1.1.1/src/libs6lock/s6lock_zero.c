/* ISC license. */

#include "s6lock.h"

s6lock_t const s6lock_zero = S6LOCK_ZERO ;
