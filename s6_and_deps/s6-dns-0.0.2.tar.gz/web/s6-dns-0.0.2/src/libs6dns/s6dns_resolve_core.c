/* ISC license. */

#include <errno.h>
#include "uint16.h"
#include "tai.h"
#include "s6dns-constants.h"
#include "s6dns-ip46.h"
#include "s6dns-domain.h"
#include "s6dns-engine.h"
#include "s6dns-resolve.h"

int s6dns_resolve_core_r (s6dns_domain_t const *d, uint16 qtype, s6dns_engine_t_ref dt, s6dns_ip46list_t const *servers, s6dns_debughook_t const *dbh, struct taia const *deadline, struct taia *stamp)
{
  return s6dns_engine_init_r(dt, servers, S6DNS_O_RECURSIVE, d->s, d->len, qtype, dbh, deadline, stamp)
   && s6dns_resolve_loop_r(dt, deadline, stamp) ;
}
