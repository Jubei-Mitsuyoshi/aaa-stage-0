/* ISC license. */

#include "uint16.h"
#include "tai.h"
#include "genalloc.h"
#include "s6dns-message.h"
#include "s6dns-engine.h"
#include "s6dns-rci.h"
#include "s6dns-resolve.h"

int s6dns_resolve_dpag_r (genalloc *ds, char const *name, unsigned int len, uint16 qtype, int qualif, s6dns_engine_t_ref dt, s6dns_rci_t const *rci, s6dns_debughook_t const *dbh, struct taia const *deadline, struct taia *stamp)
{
  s6dns_dpag_t data ;
  register int r ;
  data.ds = *ds ;
  data.rtype = qtype ;
  r = s6dns_resolve_r(name, len, qtype, &s6dns_message_parse_answer_domain, &data, qualif, dt, rci, dbh, deadline, stamp) ;
  *ds = data.ds ;
  return r ;
}
