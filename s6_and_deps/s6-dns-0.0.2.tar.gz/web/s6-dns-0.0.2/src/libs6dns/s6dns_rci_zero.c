/* ISC license. */

/* MT-unsafe */

#include "s6dns-rci.h"

s6dns_rci_t const s6dns_rci_zero = S6DNS_RCI_ZERO ;
