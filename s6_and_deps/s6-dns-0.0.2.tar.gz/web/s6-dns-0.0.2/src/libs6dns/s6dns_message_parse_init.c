/* ISC license. */

#include <errno.h>
#include "s6dns-message.h"
#include "s6dns-message-internal.h"

int s6dns_message_parse_init (s6dns_message_header_t_ref h, s6dns_message_counts_t_ref counts, char const *packet, unsigned int packetlen, unsigned int *pos)
{
  if (packetlen < 12) return (errno = EPROTO, 0) ;
  s6dns_message_header_unpack(packet, h) ;
  *counts = h->counts ;
  *pos = 12 ;
  return 1 ;
}
