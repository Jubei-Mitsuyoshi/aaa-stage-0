/* ISC license. */

#include <errno.h>
#include "bytestr.h"
#include "s6dns-domain.h"

int s6dns_domain_encode (s6dns_domain_t_ref d)
{
  register char *s = d->s ;
  register unsigned int len = d->len ;
  if (!d->len || (*s != '.')) return (errno = EINVAL, 0) ;
  while (len > 1)
  {
    register unsigned int n = byte_chr(s + 1, len - 1, '.') ;
    if (n > 63) return (errno = EINVAL, 0) ;
    *s = n++ ; s += n ; len -= n ;
  }
  if (!len) return (errno = EINVAL, 0) ;
  *s = 0 ;
  return 1 ;
}
