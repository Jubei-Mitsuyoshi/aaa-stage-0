/* ISC license. */

/* MT-unsafe */

#include "s6dns-engine.h"

s6dns_engine_t s6dns_engine_here = S6DNS_ENGINE_ZERO ;
