/* ISC license. */

#include "s6dns-engine.h"

void s6dns_engine_freen (s6dns_engine_t_ref dtl, unsigned int n)
{
  while (n--) s6dns_engine_free(dtl + n) ;
}
