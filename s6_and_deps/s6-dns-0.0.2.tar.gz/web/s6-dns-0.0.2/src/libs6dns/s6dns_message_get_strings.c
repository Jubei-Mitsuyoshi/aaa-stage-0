/* ISC license. */

#include "s6dns-message-internal.h"
#include "s6dns-message.h"

int s6dns_message_get_strings (char *s, unsigned int rdlength, char const *packet, unsigned int packetlen, unsigned int *pos)
{
  unsigned int max = rdlength, len = 0 ;
  while (rdlength)
  {
    register unsigned int start = *pos ;
    register int r = s6dns_message_get_string_internal(s + len, max - len, packet, packetlen, pos) ;
    if (r < 0) return -1 ;
    len += r ; rdlength -= *pos - start ;
  }
  return (int)len ;
}
