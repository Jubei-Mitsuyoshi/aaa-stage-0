/* ISC license. */

#include "stralloc.h"
#include "s6dns-engine.h"

void s6dns_engine_free (s6dns_engine_t_ref dt)
{
  s6dns_engine_recycle(dt) ;
  stralloc_free(&dt->sa) ;
  *dt = s6dns_engine_zero ;
}
