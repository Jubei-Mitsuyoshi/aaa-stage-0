/* ISC license. */

#include "tai.h"
#include "s6dns-engine.h"

void s6dns_engine_nextdeadline (s6dns_engine_t const *dt, struct taia *deadline)
{
  if (taia_less(&dt->deadline, deadline)) *deadline = dt->deadline ;
  if (taia_less(&dt->localdeadline, deadline)) *deadline = dt->localdeadline ;
}
