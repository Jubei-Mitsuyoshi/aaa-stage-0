/* ISC license. */

#include "s6dns-engine.h"

s6dns_engine_t const s6dns_engine_zero = S6DNS_ENGINE_ZERO ;
