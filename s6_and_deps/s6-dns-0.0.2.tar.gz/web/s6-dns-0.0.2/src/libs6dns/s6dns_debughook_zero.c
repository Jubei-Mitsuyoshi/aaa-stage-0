/* ISC license. */

#include "s6dns-engine.h"

s6dns_debughook_t const s6dns_debughook_zero = S6DNS_DEBUGHOOK_ZERO ;
