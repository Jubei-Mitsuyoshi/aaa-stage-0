/* ISC license. */

#include "stralloc.h"
#include "s6dns-rci.h"

void s6dns_rci_free (s6dns_rci_t_ref rci)
{
  stralloc_free(&rci->rules) ;
  *rci = s6dns_rci_zero ;
}
