/* ISC license. */

#include "s6dns-message.h"

s6dns_message_counts_t const s6dns_message_counts_zero = S6DNS_MESSAGE_COUNTS_ZERO ;
