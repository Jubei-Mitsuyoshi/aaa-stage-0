/* ISC license. */

#include <errno.h>
#include "error.h"
#include "genalloc.h"
#include "s6dns-constants.h"
#include "s6dns-message.h"

int s6dns_message_parse_answer_hinfo (s6dns_message_rr_t const *rr, char const *packet, unsigned int packetlen, unsigned int pos, unsigned int section, void *stuff)
{
  if ((section == 2) && (rr->rtype == S6DNS_T_HINFO))
  {
    genalloc *data = stuff ;
    s6dns_message_rr_hinfo_t hinfo ;
    register unsigned int start = pos ;
    if (!s6dns_message_get_hinfo(&hinfo, packet, packetlen, &pos)) return 0 ;
    if (rr->rdlength != pos - start) return (errno = EPROTO, 0) ;
    if (!genalloc_append(s6dns_message_rr_hinfo_t, data, &hinfo)) return -1 ;
  }
  return 1 ;
}
