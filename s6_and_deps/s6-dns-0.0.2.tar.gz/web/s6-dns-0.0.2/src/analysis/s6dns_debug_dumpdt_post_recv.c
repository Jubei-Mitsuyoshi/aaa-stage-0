/* ISC license */

#include "genwrite.h"
#include "s6dns-engine.h"
#include "s6dns-debug.h"

int s6dns_debug_dumpdt_post_recv (s6dns_engine_t const *dt, void *data)
{
  genwrite_t *gp = data ;
  (void)dt ;
  if ((*gp->put)(gp->target, "Received a packet\n", 19) < 19) return 0 ;
  if ((*gp->put)(gp->target, "\n", 1) < 1) return 0 ;
  return (*gp->flush)(gp->target) ;
}
