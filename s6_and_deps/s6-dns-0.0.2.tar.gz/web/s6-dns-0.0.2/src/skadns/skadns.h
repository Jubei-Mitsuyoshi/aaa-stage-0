/* ISC license. */

#ifndef SKADNS_H
#define SKADNS_H

#include <errno.h>
#include "skalibs-config.h"
#include "uint16.h"
#include "uint32.h"
#include "tai.h"
#include "stralloc.h"
#include "genalloc.h"
#include "gensetdyn.h"
#include "skaclient.h"
#include "s6-dns-config.h"
#include "s6dns-domain.h"

#ifdef SKALIBS_SPROOT
# define SKADNS_IPCPATH SKALIBS_SPROOT "/service/skadnsd/s"
#else
# define SKADNS_IPCPATH "/tmp/.skadnsd-socket"
#endif

#define SKADNSD_PROG S6_DNS_BINPREFIX "skadnsd"
#define SKADNS_BANNER1 "skadns v1.0 (b)\n"
#define SKADNS_BANNER1_LEN (sizeof SKADNS_BANNER1 - 1)
#define SKADNS_BANNER2 "skadns v1.0 (a)\n"
#define SKADNS_BANNER2_LEN (sizeof SKADNS_BANNER2 - 1)
#define SKADNS_MAXCONCURRENCY 1000

typedef struct skadnsanswer_s skadnsanswer_t, *skadnsanswer_t_ref ;
struct skadnsanswer_s
{
  int status ;
  char *data ;
  unsigned int len ;
} ;
#define SKADNSANSWER_ZERO { EINVAL, 0, 0 }

typedef struct skadns_s skadns_t, *skadns_t_ref ;
struct skadns_s
{
  skaclient2_t connection ;
  genalloc list ; /* array of uint16 */
  gensetdyn q ; /* set of skadnsanswer_t */
} ;
#define SKADNS_ZERO { SKACLIENT2_ZERO, GENALLOC_ZERO, GENSETDYN_INIT(skadnsanswer_t, 3, 3, 8) }
extern skadns_t const skadns_zero ;


 /* Starting and ending a session */

#define skadns_start(a, path, deadline, stamp) skaclient2_start(&(a)->connection, path, SKADNS_BANNER1, SKADNS_BANNER1_LEN, SKADNS_BANNER2, SKADNS_BANNER2_LEN, deadline, stamp)
#define skadns_start_g(a, path, deadline) skadns_start(a, path, (deadline), &STAMP)
extern int skadns_startf (skadns_t_ref, struct taia const *, struct taia *) ;
#define skadns_startf_g(a, deadline) skadns_startf(a, (deadline), &STAMP)
extern void skadns_end (skadns_t_ref) ;

                
 /* Synchronous functions */
 
extern int skadns_send (skadns_t_ref, uint16 *, s6dns_domain_t const *, uint16, struct taia const *, struct taia const *, struct taia *) ;
#define skadns_send_g(a, id, d, qtype, limit, deadline) skadns_send(a, id, d, qtype, limit, (deadline), &STAMP)
extern int skadns_cancel (skadns_t_ref, uint16, struct taia const *, struct taia *) ;
#define skadns_cancel_g(a, id, deadline) skadns_cancel(a, id, (deadline), &STAMP)


 /* Asynchronous functions */

#define skadns_fd(a) skaclient2_fd(&(a)->connection)
extern int skadns_update (skadns_t_ref) ;
#define skadns_list(a) genalloc_s(uint16 const, &(a)->list)
#define skadns_clearlist(a) ((a)->list.len = 0)
extern int skadns_packetlen (skadns_t const *, uint16) ;
extern char const *skadns_packet (skadns_t const *, uint16) ;
extern int skadns_release (skadns_t_ref, uint16) ;

#endif
