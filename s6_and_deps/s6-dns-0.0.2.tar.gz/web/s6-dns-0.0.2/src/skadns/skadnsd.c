/* ISC license. */

#include <errno.h>
#include <signal.h>
#include "uint16.h"
#include "allreadwrite.h"
#include "error.h"
#include "strerr2.h"
#include "buffer.h"
#include "stralloc.h"
#include "genalloc.h"
#include "bufalloc.h"
#include "sig.h"
#include "tai.h"
#include "djbunix.h"
#include "iopause.h"
#include "netstring.h"
#include "skaclient.h"
#include "s6dns.h"
#include "skadns.h" /* for banners */

static bufalloc asyncout = BUFALLOC_ZERO ;

typedef struct dnsio_s dnsio_t, *dnsio_t_ref ;
struct dnsio_s
{
  unsigned int xindex ;
  s6dns_engine_t dt ;
  uint16 id ;
} ;
#define DNSIO_ZERO { .xindex = SKADNS_MAXCONCURRENCY, .dt = S6DNS_ENGINE_ZERO, .id = 0 }

static void remove (dnsio_t_ref a, unsigned int *sp, unsigned int i)
{
  dnsio_t tmp ;
  s6dns_engine_recycle(&a[i].dt) ;
  tmp = a[*sp-1] ;
  a[--*sp] = a[i] ;
  a[i] = tmp ;
}

static void answer (char c)
{
  if (!bufalloc_put(bufalloc_1, &c, 1))
    strerr_diefu1sys(111, "bufalloc_put") ;
}

int main (void)
{
  dnsio_t a[SKADNS_MAXCONCURRENCY] ;
  stralloc indata = STRALLOC_ZERO ;
  struct taia deadline ;
  unsigned int sp = 0, instate = 0 ;
  PROG = "skadnsd" ;

  if (ndelay_on(0) < 0) strerr_diefu2sys(111, "ndelay_on ", "0") ;
  if (ndelay_on(1) < 0) strerr_diefu2sys(111, "ndelay_on ", "1") ;
  if (sig_ignore(SIGPIPE) < 0) strerr_diefu1sys(111, "ignore SIGPIPE") ;

  if (!s6dns_init()) strerr_diefu1sys(111, "s6dns_init") ;
  taia_now_g() ;
  taia_addsec_g(&deadline, 2) ;

  if (!skaserver2_sync_g(&asyncout, SKADNS_BANNER1, SKADNS_BANNER1_LEN, SKADNS_BANNER2, SKADNS_BANNER2_LEN, &deadline))
    strerr_diefu1sys(111, "sync with client") ;

  {
    static dnsio_t const zero = DNSIO_ZERO ;
    register unsigned int i = 0 ;
    for (; i < SKADNS_MAXCONCURRENCY ; i++) a[i] = zero ;
  }
                  
  for (;;)                
  {
    iopause_fd x[3 + sp] ;
    unsigned int i = 0, j = 3 ;
    
    taia_add_g(&deadline, &infinitetto) ;
    x[0].fd = 0 ; x[0].events = (sp < SKADNS_MAXCONCURRENCY) ? IOPAUSE_READ : 0 ;
    x[1].fd = 1 ; x[1].events = bufalloc_len(bufalloc_1) ? IOPAUSE_WRITE : 0 ;
    x[2].fd = bufalloc_fd(&asyncout) ; x[2].events = bufalloc_len(&asyncout) ? IOPAUSE_WRITE : 0 ;
    for (; i < sp ; i++)
    {
      s6dns_engine_nextdeadline(&a[i].dt, &deadline) ;
      x[j].fd = a[i].dt.fd ;
      x[j].events = 0 ;
      if (s6dns_engine_isreadable(&a[i].dt)) x[j].events |= IOPAUSE_READ ;
      if (s6dns_engine_iswritable(&a[i].dt)) x[j].events |= IOPAUSE_WRITE ;
      a[i].xindex = x[j].events ? j++ : SKADNS_MAXCONCURRENCY ;
    }

    if (iopause_g(x, j, &deadline) < 0)
      strerr_diefu1sys(111, "iopause") ;

   /*  client closed => exit  */
    if ((x[0].revents | x[1].revents) & IOPAUSE_EXCEPT) break ;

   /*  client reading => flush  */
    if (x[1].revents & IOPAUSE_WRITE)
      if ((bufalloc_flush(bufalloc_1) == -1) && !error_isagain(errno))
        strerr_diefu1sys(111, "flush stdout") ;
    if (x[2].revents & IOPAUSE_WRITE)
      if ((bufalloc_flush(&asyncout) == -1) && !error_isagain(errno))
        strerr_diefu1sys(111, "flush asyncout") ;
                        
   /*  scan pending connections  */
    for (i = 0 ; i < sp ; i++)
    {
      register int gotdata, r ;
      if (a[i].xindex >= 3+sp) continue ;
      gotdata = x[a[i].xindex].events & x[a[i].xindex].revents ;
      r = gotdata ? s6dns_engine_event_g(&a[i].dt) : s6dns_engine_timeout_g(&a[i].dt) ;
      if (!r) continue ;
      else if ((r > 0) && !gotdata) { r = -1 ; errno = ETIMEDOUT ; }
      if (r < 0)
      {
        char pack[3] ;
        uint16_pack_big(pack, a[i].id) ;
        pack[2] = errno ;
        if (!netstring_putba(&asyncout, pack, 3))
          strerr_diefu1sys(111, "netstring_putba") ;
      }
      else
      {
        register unsigned int n = s6dns_engine_packetlen(&a[i].dt) ;
        char tmp[3 + n] ;
        uint16_pack_big(tmp, a[i].id) ;
        tmp[2] = 0 ;
        byte_copy(tmp + 3, n, s6dns_engine_packet(&a[i].dt)) ;
        if (!netstring_putba(&asyncout, tmp, n + 3))
          strerr_diefu1sys(111, "netstring_putba") ;
      }
      remove(a, &sp, i--) ;
    }

   /*  client writing => parse input */
    if (buffer_len(buffer_0) || (x[0].revents & IOPAUSE_READ))
    {
      int r ;
      for (;;)
      {
        uint16 id ;
        r = sanitize_read(netstring_get(buffer_0, &indata, &instate)) ;
        if (r <= 0) break ;
        if (indata.len < 21) strerr_dief1x(100, "invalid client request") ;
        uint16_unpack_big(indata.s, &id) ;
        switch (indata.s[2])  /* protocol parsing */
        {
          case 'Q' : /* send a query */
          {
            struct taia limit ;
            uint16 qtype ;
            uint16_unpack_big(indata.s + 3, &qtype) ;
            if (byte_diff(indata.s + 5, 12, "\0\0\0\0\0\0\0\0\0\0\0"))
              tain_unpack(indata.s + 5, &limit) ;
            else taia_add_g(&limit, &infinitetto) ;
            if (!s6dns_engine_init_g(&a[sp].dt, &s6dns_rci_here.servers, 1, indata.s + 17, indata.len - 17, qtype, &limit))
            {
              answer(errno) ;
              break ;
            }
            a[sp++].id = id ;
            answer(0) ;
            break ;
          }
          case 'q' : /* cancel a query */
          {
            register unsigned int i = 0 ;
            for (; i < sp ; i++) if (a[i].id == id) break ;
            if (i >= sp)
            {
              answer(ENOENT) ;
              break ;
            }
            remove(a, &sp, i) ;
            answer(0) ;
            break ;
          }
          default : strerr_dief1x(100, "invalid client request") ;
        }
        indata.len = 0 ;
      } /* end loop: parse input */

      if (r < 0)
      {
        if (errno == EPIPE) break ; /* client closed */
        else strerr_diefu1sys(111, "read a netstring") ;
      }
    }
  } /* main iopause loop */

  return 0 ;
}
