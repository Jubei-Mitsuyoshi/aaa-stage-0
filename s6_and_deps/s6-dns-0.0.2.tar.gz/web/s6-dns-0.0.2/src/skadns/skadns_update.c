/* ISC license. */

#include <errno.h>
#include "error.h"
#include "uint16.h"
#include "alloc.h"
#include "bytestr.h"
#include "genalloc.h"
#include "gensetdyn.h"
#include "skaclient.h"
#include "skadns.h"

static int msghandler (void *stuff, char const *s, unsigned int n)
{
  skadns_t_ref a = (skadns_t_ref)stuff ;
  skadnsanswer_t *p ;
  uint16 id ;
  if (n < 3) return (errno = EPROTO, 0) ;
  uint16_unpack_big(s, &id) ;
  p = GENSETDYN_P(skadnsanswer_t, &a->q, id) ;
  if (p->status == ECANCELED)
  {
    p->status = EINVAL ;
    return gensetdyn_delete(&a->q, id) ;
  }
  if (!error_isagain(p->status)) return (errno = EINVAL, 0) ;
  if (!genalloc_readyplus(uint16, &a->list, 1)) return 0 ;
  if (!s[2])
  {
    p->data = alloc(n-3) ;
    if (!p->data) return 0 ;
    byte_copy(p->data, n-3, s+3) ;
    p->len = n-3 ;
  }
  p->status = s[2] ;
  genalloc_append(uint16, &a->list, &id) ;
  return 1 ;
}

int skadns_update (skadns_t_ref a)
{
  genalloc_setlen(uint16, &a->list, 0) ;
  return skaclient2_update(&a->connection, &msghandler, a) ;
}
