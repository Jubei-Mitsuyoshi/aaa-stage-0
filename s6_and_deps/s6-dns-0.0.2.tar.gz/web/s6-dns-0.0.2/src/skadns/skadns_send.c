/* ISC license. */

#include <errno.h>
#include "uint16.h"
#include "bytestr.h"
#include "siovec.h"
#include "tai.h"
#include "stralloc.h"
#include "gensetdyn.h"
#include "skaclient.h"
#include "s6dns-domain.h"
#include "skadns.h"

static skadnsanswer_t const skadnsanswer_initial = { .status = EAGAIN, .data = 0, .len = 0 } ;

int skadns_send (skadns_t_ref a, uint16 *u, s6dns_domain_t const *d, uint16 qtype, struct taia const *limit, struct taia const *deadline, struct taia *stamp)
{
  unsigned int i ;
  char tmp[17] = "--Q" ;
  siovec_t v[2] = { { .s = tmp, .len = 17 }, { .s = d->s, .len = d->len } } ;
  if (!gensetdyn_new(&a->q, &i)) return 0 ;
  uint16_pack_big(tmp, (uint16)i) ;
  uint16_pack_big(tmp + 3, qtype) ;
  if (limit) tain_pack(tmp + 5, limit) ; else byte_zero(tmp + 5, 12) ;
  if (!skaclient2_sendv(&a->connection, v, 2, deadline, stamp)
   || !skaclient2_getack(&a->connection, deadline, stamp))
  {
    register int e = errno ;
    gensetdyn_delete(&a->q, i) ;
    errno = e ;
    return 0 ;
  }
  *GENSETDYN_P(skadnsanswer_t, &a->q, i) = skadnsanswer_initial ;
  *u = i ;
  return 1 ;
}
