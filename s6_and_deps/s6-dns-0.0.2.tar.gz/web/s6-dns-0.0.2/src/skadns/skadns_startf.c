/* ISC license. */

#include "environ.h"
#include "tai.h"
#include "skaclient.h"
#include "skadns.h"

int skadns_startf (skadns_t_ref a, struct taia const *deadline, struct taia *stamp)
{
  static char const *const cargv[2] = { SKADNSD_PROG, 0 } ;
  return skaclient2_startf(&a->connection, cargv[0], cargv, (char const *const *)environ, SKADNS_BANNER1, SKADNS_BANNER1_LEN, SKADNS_BANNER2, SKADNS_BANNER2_LEN, SKACLIENT_OPTION_WAITPID, deadline, stamp) ;
}
