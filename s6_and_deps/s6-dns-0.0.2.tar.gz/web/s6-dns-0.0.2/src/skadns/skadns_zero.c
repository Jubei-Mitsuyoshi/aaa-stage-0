/* ISC license. */

#include "skadns.h"

skadns_t const skadns_zero = SKADNS_ZERO ;
