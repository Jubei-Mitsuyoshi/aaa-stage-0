/* ISC license. */

#include <errno.h>
#include "uint16.h"
#include "error.h"
#include "tai.h"
#include "gensetdyn.h"
#include "skaclient.h"
#include "skadns.h"

int skadns_cancel (skadns_t_ref a, uint16 id, struct taia const *deadline, struct taia *stamp)
{
  register skadnsanswer_t_ref p = GENSETDYN_P(skadnsanswer_t, &a->q, id) ;
  if (!error_isagain(p->status)) return skadns_release(a, id) ;
  {
    char pack[3] = "--q" ;
    uint16_pack_big(pack, id) ;
    if (!skaclient2_send(&a->connection, pack, 3, deadline, stamp)) return 0 ;
  }
  if (skaclient2_getack(&a->connection, deadline, stamp))
    return gensetdyn_delete(&a->q, id) ;
  if (errno != ENOENT) return 0 ;
  p->status = ECANCELED ;
  return 1 ;
}
