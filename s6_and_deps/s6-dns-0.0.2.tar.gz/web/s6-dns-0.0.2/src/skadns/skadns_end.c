/* ISC license. */

#include "alloc.h"
#include "genalloc.h"
#include "gensetdyn.h"
#include "skaclient.h"
#include "skadns.h"

static int skadnsanswer_free (char *p, void *stuff)
{
  register skadnsanswer_t_ref q = (skadnsanswer_t_ref)p ;
  alloc_free(&q->data) ;
  (void)stuff ;
  return 1 ;
}

void skadns_end (skadns_t_ref a)
{
  skaclient2_end(&a->connection) ;
  genalloc_free(uint16, &a->list) ;
  gensetdyn_iter(&a->q, &skadnsanswer_free, 0) ;
  gensetdyn_free(&a->q) ;
  *a = skadns_zero ;
}
