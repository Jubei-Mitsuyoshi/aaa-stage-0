/* ISC license. */

#include <errno.h>
#include "sgetopt.h"
#include "strerr2.h"
#include "buffer.h"
#include "fmtscan.h"
#include "tai.h"
#include "genalloc.h"
#include "ip46.h"
#include "random.h"
#include "s6dns.h"

#define USAGE "s6-dnsname [ -4 | -6 ] [ -r ] [ -t timeout ] ip"
#define dieusage() strerr_dieusage(100, USAGE)

int main (int argc, char const *const *argv)
{
  genalloc ds = GENALLOC_ZERO ; /* array of s6dns_domain_t */
  struct taia deadline ;
  ip46full_t ip = IP46FULL_ZERO ;
  unsigned int i = 0 ;
  int flagunsort = 0 ;
  int do4 = 0 ;
  int do6 = 0 ;
  PROG = "s6-dnsname" ;
  for (;;)
  {
    register int opt = subgetopt(argc, argv, "46rt:") ;
    if (opt == -1) break ;
    switch (opt)
    {
      case '4' : do4 = 1 ; break ;
      case '6' : do6 = 1 ; break ;
      case 'r' : flagunsort = 1 ; break ;
      case 't' : if (!uint0_scan(subgetopt_here.arg, &i)) dieusage() ; break ;
      default : dieusage() ;
    }
  }
  argc -= subgetopt_here.ind ; argv += subgetopt_here.ind ;
  if (argc < 1) dieusage() ;
  if (!do4 && !do6) do4 = do6 = 1 ;
  if (do4 && do6)
  {
    if (!ip46full_scan(argv[0], &ip)) dieusage() ;
  }
  else if (do6)
  {
    if (!ip6_scan(argv[0], ip.ip)) dieusage() ;
    ip.is6 = 1 ;
  }
  else if (!ip4_scan(argv[0], ip.ip)) dieusage() ;
  
  taia_now_g() ;
  if (i) taia_from_millisecs(&deadline, i) ; else deadline = infinitetto ;
  taia_add_g(&deadline, &deadline) ;
  if (!s6dns_init()) strerr_diefu1sys(111, "s6dns_init") ;
  {
    register int r = ip.is6 ? s6dns_resolve_name6_g(&ds, ip.ip, &deadline) : s6dns_resolve_name4_g(&ds, ip.ip, &deadline) ;
    if (r < 0) strerr_diefu2sys((errno == ETIMEDOUT) ? 99 : 111, "resolve ", argv[0]) ;
    if (!r) strerr_diefu4x(2, "resolve ", argv[0], ": ", s6dns_constants_error_str(errno)) ;
  }
  if (!genalloc_len(s6dns_domain_t, &ds)) return 1 ;
  if (flagunsort) random_unsort(ds.s, genalloc_len(s6dns_domain_t, &ds), sizeof(s6dns_domain_t)) ;
  {
    char buf[S6DNS_FMT_DOMAINLIST(genalloc_len(s6dns_domain_t, &ds))] ;
    unsigned int len = s6dns_fmt_domainlist(buf, S6DNS_FMT_DOMAINLIST(genalloc_len(s6dns_domain_t, &ds)), genalloc_s(s6dns_domain_t, &ds), genalloc_len(s6dns_domain_t, &ds), "\n", 1) ;
    if (!len) strerr_diefu1sys(111, "format result") ;
    if (buffer_putalign(buffer_1, buf, len) < 0) goto err ;
  }
  if (buffer_putflush(buffer_1, "\n", 1) < 0) goto err ;
  return 0 ;
 err:
  strerr_diefu1sys(111, "write to stdout") ;
}
