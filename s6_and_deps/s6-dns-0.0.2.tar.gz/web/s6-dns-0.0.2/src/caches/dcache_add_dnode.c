/* ISC license */

#include "gensetdyn.h"
#include "avltree.h"
#include "dcache.h"

int dcache_add_dnode (dcache_t_ref z, dnode_t const *node)
{
  unsigned int i ;
  if (!gensetdyn_new(&z->storage, &i)) goto err0 ;
  *GENSETDYN_P(dnode_t, &z->storage, i) = *node ;
  if (!avltree_insert(&z->by_key, i)) goto err1 ;
  if (!avltree_insert(&z->by_entry, i)) goto err2 ;
  if (!avltree_insert(&z->by_expire, i)) goto err3 ;
  return 1 ;
 err3:
  avltree_delete(&z->by_entry, i) ;
 err2:
  avltree_delete(&z->by_key, i) ;
 err1:
  gensetdyn_delete(&z->storage, i) ;
 err0:
  return 0 ;
}
