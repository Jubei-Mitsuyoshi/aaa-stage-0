/* ISC license */

#include <errno.h>
#include "uint64.h"
#include "dcache.h"

int dcache_add (dcache_t_ref z, uint64 maxsize, char const *key, unsigned int keylen, char const *data, unsigned int datalen, struct tai const *expire, struct tai const *stamp)
{
  uint64 size = keylen + datalen + DCACHE_NODE_OVERHEAD ;
  if (size > maxsize) return (errno = ERANGE, 0) ;
  if (z->size > maxsize - size)
  {
    if (!dcache_gc_by_expire(z, stamp)) return 0 ;
    if (!dcache_gc_by_entry(z, maxsize - size)) return 0 ;
  }
  return dcache_add_unbounded(z, key, keylen, data, datalen, expire, stamp) ;
}
