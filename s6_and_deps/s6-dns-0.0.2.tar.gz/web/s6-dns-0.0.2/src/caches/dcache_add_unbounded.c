/* ISC license */

#include "alloc.h"
#include "bytestr.h"
#include "tai.h"
#include "dcache.h"

int dcache_add_unbounded (dcache_t_ref z, char const *key, unsigned int keylen, char const *data, unsigned int datalen, struct tai const *expire, struct tai const *stamp)
{
  dnode_t node ;
  node.s = alloc(keylen+datalen) ;
  if (!node.s) return 0 ;
  byte_copy(node.s, keylen, key) ;
  byte_copy(node.s + keylen, datalen, data) ;
  node.keylen = keylen ;
  node.datalen = datalen ;
  node.entry = *stamp ;
  node.expire = *expire ;
  if (!dcache_add_dnode(z, &node))
  {
    alloc_free(node.s) ;
    return 0 ;
  }
  z->size += keylen+datalen ;
  z->motion += keylen+datalen ;
  return 1 ;
}
