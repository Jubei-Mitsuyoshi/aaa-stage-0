/* ISC license */

#include "uint64.h"
#include "avltree.h"
#include "dcache.h"

int dcache_gc_by_entry (dcache_t_ref z, uint64 size)
{
  while (z->size > size)
  {
    unsigned int oldest ;
    avltree_min(&z->by_entry, &oldest) ;
    if (!dcache_delete(z, oldest)) return 0 ;
  }
  return 1 ;
}
