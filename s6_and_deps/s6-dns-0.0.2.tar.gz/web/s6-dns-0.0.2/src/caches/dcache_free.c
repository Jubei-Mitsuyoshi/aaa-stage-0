/* ISC license. */

#include "gensetdyn.h"
#include "avltree.h"
#include "dcache.h"

static int dnode_ffree (char *p, void *stuff)
{
  dnode_t_ref dn = (dnode_t_ref)p ;
  dnode_free(dn) ;
  (void)stuff ;
  return 1 ;
}

void dcache_free (dcache_t_ref z)
{
  dcache_t zero = DCACHE_ZERO ;
  avltree_free(&z->by_expire) ;
  avltree_free(&z->by_entry) ;
  avltree_free(&z->by_key) ;
  gensetdyn_iter(&z->storage, &dnode_ffree, 0) ;
  gensetdyn_free(&z->storage) ;
  *z = zero ;
}
