/* ISC license */

#include "gensetdyn.h"
#include "avltree.h"
#include "dcache.h"

dnode_t_ref dcache_search (dcache_t_ref z, char const *key, unsigned int keylen)
{
  unsigned int i, j ;
  if (!gensetdyn_new(&z->storage, &i)) return 0 ;
  GENSETDYN_P(dnode_t, &z->storage, i)->s = (char *)key ;
  GENSETDYN_P(dnode_t, &z->storage, i)->keylen = keylen ;
  if (!avltree_search(&z->by_key, i, &j))
  {
    gensetdyn_delete(&z->storage, i) ;
    return 0 ;
  }
  gensetdyn_delete(&z->storage, i) ;
  return GENSETDYN_P(dnode_t, &z->storage, i) ;
}
