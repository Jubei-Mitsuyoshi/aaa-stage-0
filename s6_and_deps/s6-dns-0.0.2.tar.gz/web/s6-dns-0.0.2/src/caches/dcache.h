/* ISC license. */

#ifndef DCACHE_H
#define DCACHE_H

#include "uint64.h"
#include "alloc.h"
#include "tai.h"
#include "datastruct.h"

typedef struct dnode_s dnode_t, *dnode_t_ref ;
struct dnode_s
{
  char *s ;         
  struct tai entry ; 
  struct tai expire ;  
  unsigned int keylen ; 
  unsigned int datalen ;
} ;

#define dnode_free(dn) alloc_free((dn)->s)

typedef struct dcache_s dcache_t, *dcache_t_ref ;
struct dcache_s
{
  gensetdyn storage ; /* of dnode_t */
  avltree by_key ;
  avltree by_entry ;
  avltree by_expire ;
  uint64 size ;
  uint64 motion ;
} ;
#define DCACHE_ZERO { GENSETDYN_ZERO, AVLTREE_ZERO, AVLTREE_ZERO, AVLTREE_ZERO, 0, 0 }

#define DCACHE_NODE_OVERHEAD (16 + sizeof(dnode_t) + 3 * sizeof(avlnode))

 /* Main API */

extern int dcache_init (dcache_t_ref, uint64) ;
extern dnode_t_ref dcache_search (dcache_t_ref, char const *, unsigned int) ;
extern int dcache_add (dcache_t_ref, uint64, char const *, unsigned int, char const *, unsigned int, struct tai const *, struct tai const *) ;
#define dcache_add_g(d, maxsize, key, keylen, data, datalen, expire) dcache_add(d, maxsize, key, keylen, data, datalen, (expire), taia_secp(&STAMP))
extern void dcache_free (dcache_t_ref) ;


 /* Internals */

extern int dcache_delete (dcache_t_ref, unsigned int) ;
extern int dcache_gc_by_entry (dcache_t_ref, uint64) ;
extern int dcache_gc_by_expire (dcache_t_ref, struct tai const *) ;
#define dcache_gc_by_expire_g(d) dcache_gc_by_expire((d), taia_secp(&STAMP))
extern int dcache_add_dnode (dcache_t_ref, dnode_t const *) ;
extern int dcache_add_unbounded (dcache_t_ref, char const *, unsigned int, char const *, unsigned int, struct tai const *, struct tai const *) ;
#define dcache_add_unbounded_g(d, key, keylen, data, datalen, expire) dcache_add_unbounded(d, key, data, datalen, (expire), taia_secp(&STAMP))

#endif
