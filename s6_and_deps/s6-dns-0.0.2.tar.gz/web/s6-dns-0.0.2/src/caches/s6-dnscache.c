#include "strerr2.h"

int main (int argc, char const *const *argv, char const *const *envp)
{
  PROG = "s6-dnscache" ;
  return 0 ;
}
