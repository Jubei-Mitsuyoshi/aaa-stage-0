/* ISC license. */

#include "uint64.h"
#include "bytestr.h"
#include "tai.h"
#include "gensetdyn.h"
#include "avltree.h"
#include "dcache.h"


static int key_cmp (unsigned int a, unsigned int b, void *p)
{
  gensetdyn_ref g = p ;
  register dnode_t_ref pa = GENSETDYN_P(dnode_t, g, a) ;
  register dnode_t_ref pb = GENSETDYN_P(dnode_t, g, b) ;
  if (pa->keylen < pb->keylen) return -1 ;
  if (pb->keylen < pa->keylen) return 1 ;
  return byte_diff(pa->s, pa->keylen, pb->s) ;
}

static int entry_cmp (unsigned int a, unsigned int b, void *p)
{
  gensetdyn_ref g = p ;
  register dnode_t_ref pa = GENSETDYN_P(dnode_t, g, a) ;
  register dnode_t_ref pb = GENSETDYN_P(dnode_t, g, b) ;
  if (tai_less(&pa->entry, &pb->entry)) return -1 ;
  if (tai_less(&pb->entry, &pa->entry)) return 1 ;
  return 0 ;
}

static int expire_cmp (unsigned int a, unsigned int b, void *p)
{
  gensetdyn_ref g = p ;
  register dnode_t_ref pa = GENSETDYN_P(dnode_t, g, a) ;
  register dnode_t_ref pb = GENSETDYN_P(dnode_t, g, b) ;
  if (tai_less(&pa->expire, &pb->expire)) return -1 ;
  if (tai_less(&pb->expire, &pa->expire)) return 1 ;
  return 0 ;
}

int dcache_init (dcache_t_ref z, uint64 maxsize)
{
  gensetdyn_init(&z->storage, sizeof(dnode_t), maxsize>>9, 3, 8) ;
  avltree_init(&z->by_key, maxsize>>9, 3, 8, &key_cmp, &z->storage) ;
  avltree_init(&z->by_entry, maxsize>>9, 3, 8, &entry_cmp, &z->storage) ;
  avltree_init(&z->by_expire, maxsize>>9, 3, 8, &expire_cmp, &z->storage) ;
  z->size = 0 ;
  z->motion = 0 ;
  return 1 ;
}
