/* ISC license */

#include "gensetdyn.h"
#include "avlnode.h"
#include "avltree.h"
#include "dcache.h"

int dcache_delete (dcache_t_ref z, unsigned int i)
{
  dnode_t_ref dn = GENSETDYN_P(dnode_t, &z->storage, i) ;
  if (!avltree_delete(&z->by_expire, i)) return 0 ;
  if (!avltree_delete(&z->by_entry, i)) return 0 ;
  if (!avltree_delete(&z->by_key, i)) return 0 ;
  z->size -= dn->keylen + dn->datalen + DCACHE_NODE_OVERHEAD ;
  dnode_free(dn) ;
  return gensetdyn_delete(&z->storage, i) ;
}
