/* ISC license */

#include "tai.h"
#include "avltree.h"
#include "dcache.h"

int dcache_gc_by_expire (dcache_t_ref z, struct tai const *stamp)
{
  for (;;)
  {
    unsigned int i ;
    if (!avltree_min(&z->by_expire, &i)) break ;
    if (tai_less(stamp, &GENSETDYN_P(dnode_t, &z->storage, i)->expire)) break ;
    if (!dcache_delete(z, i)) return 0 ;
  }
  return 1 ;
}
