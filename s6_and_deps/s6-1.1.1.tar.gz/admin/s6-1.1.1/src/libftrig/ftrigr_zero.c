/* ISC license. */

#include "ftrigr.h"

ftrigr const ftrigr_zero = FTRIGR_ZERO ;
