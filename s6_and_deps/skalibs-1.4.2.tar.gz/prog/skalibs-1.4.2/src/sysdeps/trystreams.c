/* ISC license. */

#include <unistd.h>
#include <stropts.h>

int main()
{
  struct strioctl foo ;
  return 0 ;
}
