/* ISC license. */

#include <sys/types.h>
#include <sys/poll.h>
static char dummy = 0 ;
