/* ISC license. */

#include <sys/types.h>
#include <util.h>
static char dummy = 0 ;
