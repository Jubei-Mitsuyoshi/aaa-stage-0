/* ISC license. */

#include <stdint.h>

uint64_t dummy = 0 ;
