/* ISC license. */

#include <sys/types.h>
#include <unix.h>
static char dummy = 0 ;
