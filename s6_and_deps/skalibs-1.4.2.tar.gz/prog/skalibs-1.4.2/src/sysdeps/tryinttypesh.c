/* ISC license. */

#include <inttypes.h>
static char dummy = 0 ;
