/* ISC license. */

int main ()
{
  unsigned long u = 0xffffffffUL + 1UL ;
  return !!u ;
}
