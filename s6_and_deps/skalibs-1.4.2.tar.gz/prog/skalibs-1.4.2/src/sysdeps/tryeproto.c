/* ISC license. */

#include <errno.h>
static int dummy ;
#ifndef EPROTO
  syntax error !
#endif
