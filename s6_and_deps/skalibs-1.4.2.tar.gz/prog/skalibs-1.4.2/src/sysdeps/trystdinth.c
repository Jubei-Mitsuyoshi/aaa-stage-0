/* ISC license. */

#include <stdint.h>

static char dummy = 0 ;
