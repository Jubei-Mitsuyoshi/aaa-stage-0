/* ISC license. */

#include <limits.h>
#include "fmtscan-internal.h"
#include "fmtscan.h"

SCANS(int, INT)
