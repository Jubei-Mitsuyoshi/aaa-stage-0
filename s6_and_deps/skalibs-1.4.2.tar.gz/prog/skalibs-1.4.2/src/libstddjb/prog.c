/* ISC license. */

/* MT-unsafe */

#include "strerr2.h"

char const *PROG = "(none)" ;
