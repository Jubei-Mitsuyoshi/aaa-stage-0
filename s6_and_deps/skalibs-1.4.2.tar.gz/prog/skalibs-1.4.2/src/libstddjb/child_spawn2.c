/* ISC license. */

#define _CHILD_SPAWN2_
#include "child_spawn.c"
