/* ISC license. */

#include "tai.h"

struct taia const infinitetto = TAIA_INFINITE_RELATIVE ;
