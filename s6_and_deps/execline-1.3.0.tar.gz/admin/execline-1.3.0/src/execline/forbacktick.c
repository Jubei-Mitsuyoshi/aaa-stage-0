/* ISC license. */

#include <unistd.h>
#include <errno.h>
#include "allreadwrite.h"
#include "sgetopt.h"
#include "bytestr.h"
#include "buffer.h"
#include "fmtscan.h"
#include "strerr2.h"
#include "stralloc.h"
#include "genalloc.h"
#include "env.h"
#include "djbunix.h"
#include "skamisc.h"
#include "netstring.h"
#include "execline.h"
#include "exlsn.h"

#define USAGE "forbacktick [ -p | -x breakcode ] [ -n ] [ -C | -c ] [ -0 | -d delim ] key { backtickcmd... } { command... } [ remainder... ]"
#define dieusage() strerr_dieusage(100, USAGE)

int main (int argc, char const **argv, char const *const *envp)
{
  genalloc pids = GENALLOC_ZERO ; /* array of unsigned ints */
  char const *delim = " \n\r\t" ;
  unsigned int delimlen = 4 ;
  char const *x ;
  int argc1, argc2 ;
  int breakcode = -2 ;
  int crunch = 0, chomp = 0 ;
  PROG = "forbacktick" ;
  {
    subgetopt_t l = SUBGETOPT_ZERO ;
    for (;;)
    {
      register int opt = subgetopt_r(argc, argv, "pnCc0d:x:", &l) ;
      if (opt == -1) break ;
      switch (opt)
      {
        case 'p' :
        {
          if (!genalloc_ready(unsigned int, &pids, 2))
            strerr_diefu1sys(111, "genalloc_ready") ;
          break ;
        }
        case 'n' : chomp = 1 ; break ;
        case 'C' : crunch = 1 ; break ;
        case 'c' : crunch = 0 ; break ;
        case '0' : delim = "" ; delimlen = 1 ; break ;
        case 'd' : delim = l.arg ; delimlen = str_len(delim) ; break ;
        case 'x' :
        {
          unsigned short b ;
          if (!ushort_scan(l.arg, &b)) dieusage() ;
          breakcode = (int)b ;
          break ;
        }
        default : dieusage() ;
      }
    }
    argc -= l.ind ; argv += l.ind ;
  }
  if (argc < 2) strerr_dieusage(100, USAGE) ;
  x = argv[0] ; if (!*x) dieusage() ;
  argv++ ; argc-- ;
  argc1 = el_semicolon(argv) ;
  if (argc1 >= argc) strerr_dief1x(100, "unterminated first block") ;
  if (argc1 + 1 == argc) strerr_dief1x(100, "second block required") ;
  argc2 = el_semicolon(argv + argc1 + 1) ;
  if (argc1 + argc2 + 1 >= argc) strerr_dief1x(100, "unterminated second block") ;
  argv[argc1 + argc2 + 1] = 0 ;
  el_obsolescent() ;
  if (argc1 && argc2)
  {
    int pidw ;
    int p[2] ;

    if (pipe(p) < 0) strerr_diefu1sys(111, "create pipe") ;
    pidw = fork() ;
    switch (pidw)
    {
      case -1: strerr_diefu1sys(111, "fork") ;
      case 0:
      {
        PROG = "forbacktick (backtick child)" ;
        argv[argc1] = 0 ;
        fd_close(p[0]) ;
        if (fd_move(1, p[1]) < 0) strerr_diefu1sys(111, "fd_move") ;
        pathexec_run(argv[0], argv, envp) ;
        strerr_dieexec(111, argv[0]) ;
      }
    }
    fd_close(p[1]) ;
    {
      char buf[BUFFER_INSIZE] ;
      buffer b = BUFFER_INIT(&fd_read, p[0], buf, BUFFER_INSIZE) ;
      exlsn_t info = EXLSN_ZERO ;
      if (!stralloc_cats(&info.vars, x) || !stralloc_0(&info.vars))
        strerr_diefu1sys(111, "stralloc_cats") ;
      {
        elsubst blah = { 0, 0, 1 } ;
        if (!genalloc_append(elsubst, &info.data, &blah))
          strerr_diefu1sys(111, "genalloc_append") ;
      }
      if (!env_string(&satmp, argv + argc1 + 1, argc2))
        strerr_diefu1sys(111, "env_string") ;
      for (;;)
      {
        int pid ;
        int wstat ;
        info.values.len = 0 ;
        if (delimlen)
        {
          register int r = skagetlnsep(&b, &info.values, delim, delimlen) ;
          if (!r) break ;
          else if (r < 0)
          {
            if (errno != EPIPE) strerr_diefu1sys(111, "skagetlnsep") ;
            if (chomp) break ;
          }
          else info.values.len-- ;
          if (!info.values.len && crunch) continue ;
        }
        else
        {
          unsigned int unread = 0 ;
          register int r = netstring_get(&b, &info.values, &unread) ;
          if (!r) break ;
          if (r < 0) strerr_diefu1sys(111, "netstring_get") ;
        }
        if (!stralloc_0(&info.values)) strerr_diefu1sys(111, "stralloc_0") ;
        pid = fork() ;
        switch (pid)
        {
          case -1: strerr_diefu1sys(111, "fork") ;
          case 0:
          {
            PROG = "forbacktick (loop child)" ;
            el_substandrun_str(&satmp, 0, envp, &info) ;
          }
        }
        if (genalloc_s(unsigned int, &pids))
        {
          if (!genalloc_append(unsigned int, &pids, (unsigned int *)&pid))
            strerr_diefu1sys(111, "genalloc_append") ;
        }
        else
        {
          if (wait_pid(&wstat, pid) < 0)
            strerr_diefu2sys(111, "wait for ", argv[argc1+1]) ;
          if (wait_status(wstat) == breakcode) break ;
        }
      }
      satmp.len = 0 ;
      exlsn_free(&info) ;
    }
    fd_close(p[0]) ;
    if (!genalloc_append(unsigned int, &pids, (unsigned int *)&pidw))
      strerr_diefu1sys(111, "genalloc_append") ;
  }
  if (!waitn(genalloc_s(unsigned int, &pids), genalloc_len(unsigned int, &pids))) strerr_diefu1sys(111, "waitn") ;
  genalloc_free(unsigned int, &pids) ;
  pathexec0_run(argv + argc1 + argc2 + 2, envp) ;
  strerr_dieexec(111, argv[argc1 + argc2 + 2]) ;
}
