/* ISC license. */

#include <unistd.h>
#include "sgetopt.h"
#include "strerr2.h"
#include "fmtscan.h"
#include "djbunix.h"
#include "execline.h"

#define USAGE "loopwhile [ -n ] [ -x exitcode ] { prog... }"

int main (int argc, char const **argv, char const *const *envp)
{
  int argc1 ;
  int not = 0, cont = 1 ;
  unsigned short e = 0 ;
  PROG = "loopwhile" ;
  {
    subgetopt_t l = SUBGETOPT_ZERO ;
    for (;;)
    {
      register int opt = subgetopt_r(argc, argv, "nx:", &l) ;
      if (opt == -1) break ;
      switch (opt)
      {
        case 'n' : not = 1 ; break ;
        case 'x' : if (ushort_scan(l.arg, &e)) break ;
        default : strerr_dieusage(100, USAGE) ;
      }
    }
    argc -= l.ind ; argv += l.ind ;
  }
  argc1 = el_semicolon(argv) ;
  if (!argc1) strerr_dief1x(100, "empty block not allowed") ;
  if (argc1 >= argc) strerr_dief1x(100, "unterminated block") ;
  argv[argc1] = 0 ;
  el_obsolescent() ;
  while (cont)
  {
    int wstat ;
    int pid = fork() ;
    switch (pid)
    {
      case -1: strerr_diefu1sys(111, "fork") ;
      case 0:
      {
        pathexec_run(argv[0], argv, envp) ;
        strerr_diewu2sys(111, "spawn ", argv[0]) ;
      }
    }
    if (wait_pid(&wstat, pid) == -1) strerr_diefu1sys(111, "wait") ;
    cont = not != (wait_status(wstat) == (int)e) ;
  }
  pathexec0_run(argv + argc1 + 1, envp) ;
  strerr_dieexec(111, argv[argc1 + 1]) ;
}
