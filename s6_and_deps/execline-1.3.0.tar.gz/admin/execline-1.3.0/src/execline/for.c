/* ISC license. */

#include <unistd.h>
#include "sgetopt.h"
#include "bytestr.h"
#include "fmtscan.h"
#include "strerr2.h"
#include "stralloc.h"
#include "genalloc.h"
#include "env.h"
#include "djbunix.h"
#include "skamisc.h"
#include "execline.h"
#include "exlsn.h"

#define USAGE "for [ -p | -x breakcode ] key { values... } { command... } [ remainder... ]"
#define dieusage() strerr_dieusage(100, USAGE)

int main (int argc, char const **argv, char const *const *envp)
{
  char const *x ;
  int argc1, argc2 ;
  int breakcode = -2 ;
  int flagpar = 0 ;
  PROG = "for" ;
  {
    subgetopt_t l = SUBGETOPT_ZERO ;
    for (;;)
    {
      register int opt = subgetopt_r(argc, argv, "px:", &l) ;
      if (opt == -1) break ;
      switch (opt)
      {
        case 'p' : flagpar = 1 ; break ;
        case 'x' :
        {
          unsigned short b ;
          if (!ushort_scan(l.arg, &b)) dieusage() ;
          breakcode = (int)b ;
          break ;
        }
        default : dieusage() ;
      }
    }
    argc -= l.ind ; argv += l.ind ;
  }
  if (argc < 2) dieusage() ;
  x = argv[0] ; if (!*x) dieusage() ;
  argv++ ; argc-- ;
  argc1 = el_semicolon(argv) ;
  if (argc1 >= argc) strerr_dief1x(100, "unterminated values block") ;
  if (argc1 + 1 == argc) return 0 ;
  argc2 = el_semicolon(argv + argc1 + 1) ;
  if (argc1 + argc2 + 1 >= argc) strerr_dief1x(100, "unterminated command block") ;
  el_obsolescent() ;
  if (argc1 && argc2)
  {
    exlsn_t info = EXLSN_ZERO ;
    unsigned int pids[flagpar ? argc1 : 1] ;
    unsigned int i = 0 ;
    argv[argc1 + argc2 + 1] = 0 ;
    if (!stralloc_cats(&info.vars, x) || !stralloc_0(&info.vars))
      strerr_diefu1sys(111, "stralloc_cats") ;
    {
      elsubst blah = { 0, 0, 1 } ;
      if (!genalloc_append(elsubst, &info.data, &blah))
        strerr_diefu1sys(111, "genalloc_append") ;
    }
    if (!env_string(&satmp, argv + argc1 + 1, argc2))
      strerr_diefu1sys(111, "env_string") ;

    for (; i < (unsigned int)argc1 ; i++)
    {
      int pid = fork() ;
      switch (pid)
      {
        case -1: strerr_diefu1sys(111, "fork") ;
        case 0:
        {
          PROG = "for (child)" ;
          info.values.len = 0 ;
          if (!stralloc_cats(&info.values, argv[i]) || !stralloc_0(&info.values))
            strerr_diefu1sys(111, "stralloc_cats") ;
          el_substandrun_str(&satmp, 0, envp, &info) ;
        }
      }
      if (flagpar) pids[i] = pid ;
      else
      {
        int wstat ;
        if (wait_pid(&wstat, pid) == -1)
          strerr_diefu2sys(111, "wait for ", argv[argc1+1]) ;
        if (wait_status(wstat) == breakcode) break ;
      }
    }
    stralloc_free(&satmp) ;
    exlsn_free(&info) ;
    if (flagpar)
      if (!waitn(pids, argc1)) strerr_diefu1sys(111, "waitn") ;
  }
  pathexec0_run(argv + argc1 + argc2 + 2, envp) ;
  strerr_dieexec(111, argv[argc1 + argc2 + 2]) ;
}
