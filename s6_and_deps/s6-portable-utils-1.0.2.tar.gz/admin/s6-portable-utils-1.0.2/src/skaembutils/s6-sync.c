/* ISC license. */

#include <unistd.h>

int main (void)
{
  sync() ;
  return 0 ;
}
