/* ISC license. */

int main ()
{
  return 0 ;
}
